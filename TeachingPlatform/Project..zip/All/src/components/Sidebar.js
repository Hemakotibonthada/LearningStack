import React from 'react';

const Sidebar = () => {
    return <div>Sidebar Component</div>;
};

export default Sidebar;
